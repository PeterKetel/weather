from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_bcrypt import Bcrypt

app = Flask(__name__)
app.config['SECRET_KEY'] = 'ffe339824e47150921e3273957c015323c5d77f133ca5e36001f7887e3109126'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///weather.db'
db = SQLAlchemy(app)
bcrypt = Bcrypt(app)

from weather import routes

